ten= input("Nhập tên của bạn: ")
tuoi= input("Nhập tuổi của bạn: ")
print("Xin chào, tôi tên là", ten)
print("Tôi", tuoi, "tuổi")