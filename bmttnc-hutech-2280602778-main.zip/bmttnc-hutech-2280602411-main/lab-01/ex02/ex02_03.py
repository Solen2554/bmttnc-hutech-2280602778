so = int(input("Nhap mot so: "))
if so % 2 == 0:
    print("So ban vua nhap la so chan")
else:
    print("So ban vua nhap la so le")   