ban_kinh = float(input("Nhập bán kính hình tròn: "))
pi = 3.14
chu_vi = 2 * pi * ban_kinh
dien_tich = pi * ban_kinh ** 2
print("Chu vi hình tròn là", chu_vi)
print("Diện tích hình tròn là", dien_tich)