print("Hello, World!")
print("Hello, Python!")
print("My name is Loc")
print("I'm learning Python")